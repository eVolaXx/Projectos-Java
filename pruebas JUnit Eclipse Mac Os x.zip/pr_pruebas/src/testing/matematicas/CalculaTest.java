package testing.matematicas;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculaTest {

	@Test
	public void testSuma() {
		fail("Not yet implemented");
	}

	@Test
	public void testProducto() {
		fail("Not yet implemented");
	}

}
